'use strict';

/* ---------------- constants ---------------- */
const TABS = [
  {id:'dashboard', label:'Home', icon:'🏠'},
  {id:'claims', label:'Claims', icon:'📋'},
  {id:'staff', label:'Team', icon:'🧑‍💼'},
  {id:'insurers', label:'Insurers', icon:'🏥'},
  {id:'reports', label:'Reports', icon:'📊'},
];

const STATUS_META = {
  'Eligibility Check':          {c:'#6B6690'},
  'Pre-Auth Sent':              {c:'#2FA8E0'},
  'Pre-Auth Query':             {c:'#F5A524'},
  'Pre-Auth Approved':          {c:'#12B886'},
  'Admitted / Under Treatment': {c:'#8B5CF6'},
  'Enhancement Requested':      {c:'#F5A524'},
  'Discharge Initiated':        {c:'#12B886'},
  'Final Bill Submitted':       {c:'#2FA8E0'},
  'Final Query':                {c:'#F5A524'},
  'Final Approved':             {c:'#12B886'},
  'Settled':                    {c:'#16A34A'},
  'Closed':                     {c:'#6B6690'},
  'Denied / Rejected':          {c:'#F5476B'},
};
const STATUS_LIST = Object.keys(STATUS_META);
const TERMINAL = new Set(['Settled','Closed','Denied / Rejected']);
const PRIORITY_META = { 'Normal':{c:'#6B6690'}, 'Urgent':{c:'#F5A524'}, 'Critical':{c:'#F5476B'} };
const ROLE_COLOR = {'Manager':'#6D5EF5','Insurance Coordinator':'#2FA8E0','Claim Executive':'#8B5CF6'};
const CLAIM_TYPES = ['Cashless','Reimbursement'];
const ACTIVITY_TYPES = [
  'Document Collection','Documents Submitted to Insurer/TPA','Pre-Auth Follow-up Call',
  'Query Reply Submitted','Enhancement Request Sent','Discharge Coordination',
  'Final Bill Submission','Settlement Follow-up','Call to Insurer / TPA',
  'Site Visit / In-person Follow-up','Other'
];
const ROLES = ['Manager','Insurance Coordinator','Claim Executive'];
const INSURER_TYPES = ['Scheme','TPA','Insurer'];

/* ---------------- state ---------------- */
const ST = { staff:[], insurers:[], claims:[], events:[], settings:{}, tab:'dashboard',
  claimFilter:{status:'', insurer:'', staff:'', overdue:false}, insurerFilter:'' };

function getLocalUserId(){ try{ return localStorage.getItem('hc360_user_id') || null; }catch(e){ return null; } }
function setLocalUserId(id){ try{ if(id) localStorage.setItem('hc360_user_id', id); else localStorage.removeItem('hc360_user_id'); }catch(e){} }

/* ---------------- utils ---------------- */
function esc(s){ return (s===undefined||s===null?'':String(s)).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
function todayISO(){ return new Date().toISOString().slice(0,10); }
function fmtDate(iso){ if(!iso) return '—'; const d=new Date(iso+'T00:00:00'); if(isNaN(d)) return esc(iso); return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}); }
function fmtDateTime(ts){ const d=new Date(ts); return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short'}) + ', ' + d.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}); }
function money(n){ n = Number(n)||0; return '₹' + n.toLocaleString('en-IN',{maximumFractionDigits:0}); }
function isOverdue(c){ return c.followUpDate && c.followUpDate < todayISO() && !TERMINAL.has(c.status); }
function staffName(id){ const s = ST.staff.find(x=>x.id===id); return s ? s.name : '—'; }
function insurerName(id){ const s = ST.insurers.find(x=>x.id===id); return s ? s.name : '—'; }
function badge(label, color){ return `<span class="badge" style="--c:${color}">${esc(label)}</span>`; }
function toast(msg){ const t=document.getElementById('toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toast._t); toast._t=setTimeout(()=>t.classList.remove('show'), 2400); }
function currentUser(){ return ST.staff.find(s=>s.id===getLocalUserId()) || null; }
function avatarGradient(name){
  let hash=0; for(let i=0;i<name.length;i++) hash = name.charCodeAt(i) + ((hash<<5)-hash);
  const hue = Math.abs(hash)%360;
  return `linear-gradient(135deg, hsl(${hue},70%,55%), hsl(${(hue+45)%360},70%,60%))`;
}

/* ---------------- input guards ----------------
   Keeps amount fields numeric-only, integer fields clamped, phone fields
   digits-and-symbols-only, and gives every length-limited textarea a live
   "used / max" counter. Called once for the whole document at boot, and
   again on every dynamically-built form sheet. */
function guardMoneyInput(el){
  if(el.dataset.guarded) return; el.dataset.guarded = '1';
  const max = Number(el.getAttribute('max')) || 99999999;
  el.addEventListener('keydown', e=>{ if(['e','E','+','-','.'].includes(e.key)) e.preventDefault(); });
  el.addEventListener('wheel', ()=> el.blur(), {passive:true});
  el.addEventListener('paste', e=>{
    e.preventDefault();
    const text = (e.clipboardData || window.clipboardData).getData('text');
    const digits = text.replace(/[^0-9]/g,'');
    document.execCommand && document.execCommand('insertText', false, digits);
  });
  el.addEventListener('input', ()=>{
    let v = el.value.replace(/[^0-9]/g,'');
    if(v.length > 1) v = v.replace(/^0+/, '') || '0';
    if(v && Number(v) > max) v = String(max);
    el.value = v;
  });
}
function guardIntInput(el){
  guardMoneyInput(el); // same digits-only behaviour, just a distinct name for clarity at call sites
}
function guardPhoneInput(el){
  if(el.dataset.guarded) return; el.dataset.guarded = '1';
  el.addEventListener('input', ()=>{
    el.value = el.value.replace(/[^0-9+\-\s]/g,'');
  });
}
function attachCounter(el){
  if(el.dataset.counted) return; el.dataset.counted = '1';
  const max = Number(el.getAttribute('maxlength')) || 0;
  if(!max) return;
  const counter = document.createElement('div');
  counter.className = 'charcount';
  el.insertAdjacentElement('afterend', counter);
  const update = ()=>{ counter.textContent = `${el.value.length} / ${max}`; counter.classList.toggle('near', el.value.length >= max - Math.max(10, Math.round(max*0.1))); };
  el.addEventListener('input', update);
  update();
}
function wireInputGuards(root){
  root = root || document;
  root.querySelectorAll('input[data-guard="money"]').forEach(guardMoneyInput);
  root.querySelectorAll('input[data-guard="int"]').forEach(guardIntInput);
  root.querySelectorAll('input[data-guard="phone"]').forEach(guardPhoneInput);
  root.querySelectorAll('textarea[data-counter], textarea[maxlength]').forEach(attachCounter);
}

/* ---------------- API layer ---------------- */
async function api(path, opts){
  opts = opts || {};
  const headers = Object.assign({'Content-Type':'application/json'}, opts.headers||{});
  let res;
  try{
    res = await fetch(path, Object.assign({}, opts, {headers}));
  }catch(err){
    setConn(false);
    throw new Error('Cannot reach the server. Check your network / that the app container is running.');
  }
  setConn(true);
  if(!res.ok){
    let msg = 'Request failed (' + res.status + ')';
    try{ const j = await res.json(); if(j.error) msg = j.error; }catch(e){}
    throw new Error(msg);
  }
  const ct = res.headers.get('content-type')||'';
  if(ct.includes('application/json')) return res.json();
  return res.text();
}
function setConn(ok){
  const dot = document.getElementById('connDot');
  if(dot) dot.classList.toggle('off', !ok);
}
const Staff = {
  list: ()=> api('/api/staff'),
  create: (d)=> api('/api/staff', {method:'POST', body:JSON.stringify(d)}),
  update: (id,d)=> api('/api/staff/'+id, {method:'PUT', body:JSON.stringify(d)}),
  remove: (id)=> api('/api/staff/'+id, {method:'DELETE'}),
};
const Insurers = {
  list: ()=> api('/api/insurers'),
  create: (d)=> api('/api/insurers', {method:'POST', body:JSON.stringify(d)}),
  update: (id,d)=> api('/api/insurers/'+id, {method:'PUT', body:JSON.stringify(d)}),
  remove: (id)=> api('/api/insurers/'+id, {method:'DELETE'}),
};
const Claims = {
  list: ()=> api('/api/claims'),
  create: (d)=> api('/api/claims', {method:'POST', body:JSON.stringify(d)}),
  update: (id,d)=> api('/api/claims/'+id, {method:'PUT', body:JSON.stringify(d)}),
  remove: (id)=> api('/api/claims/'+id, {method:'DELETE'}),
};
const Events = {
  list: (params)=> api('/api/events' + (params ? '?'+new URLSearchParams(params).toString() : '')),
  create: (d)=> api('/api/events', {method:'POST', body:JSON.stringify(d)}),
};
const Settings = {
  get: ()=> api('/api/settings'),
  set: (key,value)=> api('/api/settings/'+key, {method:'PUT', body:JSON.stringify({value})}),
};

async function loadAll(){
  const [staff, insurers, claims, events, settings] = await Promise.all([
    Staff.list(), Insurers.list(), Claims.list(), Events.list({limit:500}), Settings.get(),
  ]);
  ST.staff = staff; ST.insurers = insurers; ST.claims = claims; ST.events = events; ST.settings = settings;
}

/* ---------------- navigation ---------------- */
function renderNav(){
  const nav = document.getElementById('bottomNav');
  nav.innerHTML = TABS.map(t => `<button data-tab="${t.id}" class="${ST.tab===t.id?'active':''}"><span class="ic">${t.icon}</span>${esc(t.label)}</button>`).join('');
  nav.querySelectorAll('button').forEach(b => b.addEventListener('click', ()=> switchTab(b.dataset.tab)));
}
function switchTab(id){
  ST.tab = id;
  document.querySelectorAll('section.tab').forEach(s => s.classList.toggle('active', s.id==='tab-'+id));
  document.querySelectorAll('nav.bottom button').forEach(b => b.classList.toggle('active', b.dataset.tab===id));
  renderActiveTab();
}
function switchTabNoNav(id){
  document.querySelectorAll('section.tab').forEach(s => s.classList.toggle('active', s.id==='tab-'+id));
  document.querySelectorAll('nav.bottom button').forEach(b => b.classList.toggle('active', b.dataset.tab===id));
  if(id==='settings') renderSettings();
}
function renderActiveTab(){
  if(ST.tab==='dashboard') renderDashboard();
  else if(ST.tab==='claims') renderClaims();
  else if(ST.tab==='staff') renderStaff();
  else if(ST.tab==='insurers') renderInsurers();
  else if(ST.tab==='reports') renderReports();
}

/* ---------------- modal helpers ---------------- */
function openSheet(title, bodyHtml, onMount){
  const overlay = document.getElementById('overlay');
  const sheet = document.getElementById('sheet');
  sheet.innerHTML = `<div class="sheet-head"><h3>${esc(title)}</h3><button class="sheet-close" id="sheetCloseBtn">✕</button></div>${bodyHtml}`;
  overlay.classList.add('open');
  document.getElementById('sheetCloseBtn').addEventListener('click', closeSheet);
  overlay.onclick = (e)=>{ if(e.target===overlay) closeSheet(); };
  if(onMount) onMount(sheet);
}
function closeSheet(){ document.getElementById('overlay').classList.remove('open'); }

/* ---------------- header/settings sync ---------------- */
function refreshHeader(){
  document.getElementById('hospitalNameHdr').textContent = ST.settings.hospitalName || 'Claims360';
  const u = currentUser();
  document.getElementById('userHdr').textContent = u ? `${u.name} · ${u.role}` : 'Set up your profile →';
  const lanHint = document.getElementById('lanHint');
  if(lanHint) lanHint.textContent = window.location.origin;
}

/* ================= DASHBOARD ================= */
function renderDashboard(){
  refreshHeader();
  document.getElementById('dashDateLine').textContent = new Date().toLocaleDateString('en-IN',{weekday:'long', day:'2-digit', month:'long', year:'numeric'});

  const onboardBox = document.getElementById('onboardBox');
  if(ST.staff.length===0){
    onboardBox.innerHTML = `<div class="onboard"><h4>Let's set this up</h4><p>Add your team — coordinators, claim executives, and yourself as manager — then log your empanelled insurers.</p><button class="btn" id="onbAddStaff">+ Add first team member</button></div>`;
    document.getElementById('onbAddStaff').addEventListener('click', ()=> switchTab('staff'));
  } else if(!getLocalUserId()){
    onboardBox.innerHTML = `<div class="onboard"><h4>One more step</h4><p>Tell the app who's using this device, so your own work gets tracked too.</p><button class="btn" id="onbSettings">Go to settings</button></div>`;
    document.getElementById('onbSettings').addEventListener('click', ()=> switchTabNoNav('settings'));
  } else {
    onboardBox.innerHTML = '';
  }

  const active = ST.claims.filter(c=>!TERMINAL.has(c.status));
  const preAuthPending = ST.claims.filter(c=> !TERMINAL.has(c.status) && /Pre-Auth/.test(c.status));
  const overdue = ST.claims.filter(isOverdue);
  const ym = new Date().toISOString().slice(0,7);
  const settledThisMonth = ST.claims.filter(c => c.status==='Settled' && (c.updatedAt||'').slice(0,7)===ym);
  const settledAmt = settledThisMonth.reduce((s,c)=> s + (Number(c.settledAmount)||0), 0);

  document.getElementById('statGrid').innerHTML = `
    <div class="stat"><span class="n">${active.length}</span><span class="l">Active claims</span></div>
    <div class="stat warn"><span class="n">${preAuthPending.length}</span><span class="l">Pending pre-auth</span></div>
    <div class="stat danger"><span class="n">${overdue.length}</span><span class="l">Overdue follow-ups</span></div>
    <div class="stat good"><span class="n">${money(settledAmt)}</span><span class="l">Settled this month</span></div>
  `;

  const u = currentUser();
  const myBox = document.getElementById('myWorkBox');
  document.getElementById('myWorkDate').textContent = new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short'});
  if(!u){
    myBox.innerHTML = `<div class="card small mut">Set "I am using this device as" in Settings to see your own work here.</div>`;
  } else {
    const todayStr = todayISO();
    const myEventsToday = ST.events.filter(e => e.staffId===u.id && new Date(e.createdAt).toISOString().slice(0,10)===todayStr);
    const myOpenClaims = ST.claims.filter(c => (c.coordinatorId===u.id || c.executiveId===u.id) && !TERMINAL.has(c.status));
    myBox.innerHTML = `<div class="card row between"><div><b style="font-size:22px;font-family:var(--font-mono);color:var(--primary);">${myEventsToday.length}</b><div class="small mut">actions logged today</div></div><div style="text-align:right;"><b style="font-size:22px;font-family:var(--font-mono);color:var(--teal);">${myOpenClaims.length}</b><div class="small mut">open claims on you</div></div></div>`;
  }

  const perfBox = document.getElementById('staffPerfBox');
  const weekAgo = Date.now() - 7*24*3600*1000;
  if(ST.staff.length===0){
    perfBox.innerHTML = `<div class="card small mut">No team members yet.</div>`;
  } else {
    perfBox.innerHTML = ST.staff.filter(s=>s.active!==false).map(s=>{
      const openClaims = ST.claims.filter(c => (c.coordinatorId===s.id || c.executiveId===s.id) && !TERMINAL.has(c.status)).length;
      const acts7d = ST.events.filter(e => e.staffId===s.id && new Date(e.createdAt).getTime() >= weekAgo).length;
      const settled = ST.claims.filter(c => (c.coordinatorId===s.id || c.executiveId===s.id) && c.status==='Settled' && (c.updatedAt||'').slice(0,7)===ym);
      const settledSum = settled.reduce((a,c)=>a+(Number(c.settledAmount)||0),0);
      return `<div class="card">
        <div class="row between"><b class="small" style="font-size:13.5px;">${esc(s.name)}</b>${badge(s.role, ROLE_COLOR[s.role]||'#6B6690')}</div>
        <div class="row wrap" style="gap:16px;margin-top:9px;">
          <div><b class="mono" style="font-size:14px;">${openClaims}</b><div class="small mut">open claims</div></div>
          <div><b class="mono" style="font-size:14px;">${acts7d}</b><div class="small mut">actions / 7d</div></div>
          <div><b class="mono" style="font-size:14px;">${settled.length}</b><div class="small mut">settled (mo.)</div></div>
          <div><b class="mono" style="font-size:14px;">${money(settledSum)}</b><div class="small mut">amount (mo.)</div></div>
        </div>
      </div>`;
    }).join('') || `<div class="card small mut">No active team members.</div>`;
  }

  const insBox = document.getElementById('insurerPerfBox');
  const byInsurer = {};
  ST.claims.forEach(c=>{
    if(!c.insurerId) return;
    byInsurer[c.insurerId] = byInsurer[c.insurerId] || {open:0, claimed:0, settled:0};
    if(!TERMINAL.has(c.status)){ byInsurer[c.insurerId].open++; byInsurer[c.insurerId].claimed += Number(c.claimedAmount)||0; }
    if(c.status==='Settled') byInsurer[c.insurerId].settled += Number(c.settledAmount)||0;
  });
  const rows = Object.entries(byInsurer).sort((a,b)=>b[1].open-a[1].open).slice(0,8);
  insBox.innerHTML = rows.length ? `<div class="card">` + rows.map(([id,d])=>
    `<div class="list-row"><span>${esc(insurerName(id))}</span><span class="mono">${d.open} open · ${money(d.settled)} settled</span></div>`
  ).join('') + `</div>` : `<div class="card small mut">No claims logged against an insurer yet.</div>`;

  const feed = [...ST.events].sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt)).slice(0,15);
  const feedBox = document.getElementById('recentActivityBox');
  if(feed.length===0){
    feedBox.innerHTML = `<div class="empty"><div class="big">🗂️</div><h4>No activity yet</h4><p>Add a claim and start logging follow-ups — this feed fills up as your team works.</p></div>`;
  } else {
    feedBox.innerHTML = feed.map(e => {
      const c = ST.claims.find(x=>x.id===e.claimId);
      const label = e.kind==='status' ? `Status → ${e.statusTo}` : (e.activityType||'Activity');
      return `<div class="tl-item"><div class="tl-dot"></div><div class="tl-body">
        <div class="top">${esc(staffName(e.staffId))} <span class="mut small">· ${esc(label)}</span></div>
        <div class="meta">${c ? esc(c.patientName)+' · '+esc(c.claimNumber) : 'Unknown claim'} · ${fmtDateTime(e.createdAt)}</div>
        ${e.note ? `<div class="note">${esc(e.note)}</div>` : ''}
      </div></div>`;
    }).join('');
  }
}

/* ================= CLAIMS ================= */
function renderClaimFilterChips(){
  const box = document.getElementById('claimFilterChips');
  const statusOpts = ['<option value="">Any status</option>'].concat(STATUS_LIST.map(s=>`<option value="${esc(s)}" ${ST.claimFilter.status===s?'selected':''}>${esc(s)}</option>`)).join('');
  const insurerOpts = ['<option value="">Any insurer</option>'].concat(ST.insurers.map(i=>`<option value="${i.id}" ${ST.claimFilter.insurer===i.id?'selected':''}>${esc(i.name)}</option>`)).join('');
  const staffOpts = ['<option value="">Any staff</option>'].concat(ST.staff.map(s=>`<option value="${s.id}" ${ST.claimFilter.staff===s.id?'selected':''}>${esc(s.name)}</option>`)).join('');
  box.innerHTML = `
    <span class="chip"><select id="fltStatus">${statusOpts}</select></span>
    <span class="chip"><select id="fltInsurer">${insurerOpts}</select></span>
    <span class="chip"><select id="fltStaff">${staffOpts}</select></span>
    <button class="chip ${ST.claimFilter.overdue?'active':''}" id="fltOverdue">⏰ Overdue only</button>
  `;
  document.getElementById('fltStatus').addEventListener('change', e=>{ ST.claimFilter.status = e.target.value; renderClaims(true); });
  document.getElementById('fltInsurer').addEventListener('change', e=>{ ST.claimFilter.insurer = e.target.value; renderClaims(true); });
  document.getElementById('fltStaff').addEventListener('change', e=>{ ST.claimFilter.staff = e.target.value; renderClaims(true); });
  document.getElementById('fltOverdue').addEventListener('click', ()=>{ ST.claimFilter.overdue = !ST.claimFilter.overdue; renderClaims(); });
}
function renderClaims(skipChips){
  if(!skipChips) renderClaimFilterChips();
  const q = (document.getElementById('claimSearch').value||'').trim().toLowerCase();
  let list = [...ST.claims];
  if(ST.claimFilter.status) list = list.filter(c=>c.status===ST.claimFilter.status);
  if(ST.claimFilter.insurer) list = list.filter(c=>c.insurerId===ST.claimFilter.insurer);
  if(ST.claimFilter.staff) list = list.filter(c=>c.coordinatorId===ST.claimFilter.staff || c.executiveId===ST.claimFilter.staff);
  if(ST.claimFilter.overdue) list = list.filter(isOverdue);
  if(q) list = list.filter(c => [c.patientName,c.claimNumber,c.uhid,c.policyNumber].filter(Boolean).join(' ').toLowerCase().includes(q));
  list.sort((a,b)=> new Date(b.updatedAt) - new Date(a.updatedAt));

  const box = document.getElementById('claimsList');
  if(list.length===0){
    box.innerHTML = `<div class="empty"><div class="big">📋</div><h4>No claims match</h4><p>Try clearing filters, or add a new claim to get started.</p></div>`;
  } else {
    box.innerHTML = list.map(c=>{
      const sm = STATUS_META[c.status] || {c:'#6B6690'};
      const pm = PRIORITY_META[c.priority] || {c:'#6B6690'};
      return `<div class="claim-card" style="--card-accent:${sm.c}" data-id="${c.id}">
        <div class="row between"><h3>${esc(c.patientName)}</h3>${badge(c.status, sm.c)}</div>
        <div class="sub">${esc(c.claimNumber)} · ${esc(insurerName(c.insurerId))} · ${esc(c.claimType||'')}</div>
        <div class="row wrap" style="gap:6px;">${badge(c.priority||'Normal', pm.c)}
          ${c.coordinatorId?`<span class="small mut">Coord: ${esc(staffName(c.coordinatorId))}</span>`:''}
          ${c.executiveId?`<span class="small mut">Exec: ${esc(staffName(c.executiveId))}</span>`:''}
        </div>
        <div class="amounts">
          <div><b>${money(c.claimedAmount)}</b><span class="mut">claimed</span></div>
          <div><b>${money(c.settledAmount)}</b><span class="mut">settled</span></div>
          <div>${isOverdue(c) ? `<span class="overdue-tag">Follow-up overdue: ${fmtDate(c.followUpDate)}</span>` : (c.followUpDate?`<span class="mut">Next: ${fmtDate(c.followUpDate)}</span>`:'')}</div>
        </div>
      </div>`;
    }).join('');
    box.querySelectorAll('.claim-card').forEach(el => el.addEventListener('click', ()=> openClaimDetail(el.dataset.id)));
  }
}
document.getElementById('btnRegisterPatient').addEventListener('click', ()=> openClaimForm(null, 'patient'));
document.getElementById('btnNewClaim').addEventListener('click', ()=> openClaimForm(null, 'claim'));
document.getElementById('fabNewClaim').addEventListener('click', ()=> openClaimForm());
document.addEventListener('input', (e)=>{ if(e.target && e.target.id==='claimSearch') renderClaims(true); });

function staffOptionsHtml(role, selected){
  const filtered = role ? ST.staff.filter(s=>s.role===role && s.active!==false) : ST.staff.filter(s=>s.active!==false);
  return '<option value="">— none —</option>' + filtered.map(s=>`<option value="${s.id}" ${selected===s.id?'selected':''}>${esc(s.name)}</option>`).join('');
}
function insurerOptionsHtml(selected){
  return ST.insurers.filter(i=>i.active!==false).map(i=>`<option value="${i.id}" ${selected===i.id?'selected':''}>${esc(i.name)} (${i.type})</option>`).join('');
}

function claimFormHtml(c, mode){
  c = c || {};
  const isPatientRegistration = mode === 'patient';
  return `<form id="claimForm">
    ${isPatientRegistration ? '<div class="form-callout"><b>Patient registration</b><span>Capture the patient and coverage details first. You can update the claim status and financials later.</span></div>' : ''}
    <div class="field"><label>Patient name *</label><input required maxlength="100" id="cf_patientName" value="${esc(c.patientName||'')}"></div>
    <div class="field-row">
      <div class="field"><label>UHID</label><input maxlength="40" id="cf_uhid" value="${esc(c.uhid||'')}"></div>
      <div class="field"><label>Admission / IP no.</label><input maxlength="40" id="cf_admissionNumber" value="${esc(c.admissionNumber||'')}"></div>
    </div>
    <div class="field"><label>Insurer / TPA / scheme *</label><select required id="cf_insurerId">${insurerOptionsHtml(c.insurerId)}</select></div>
    <div class="field-row">
      <div class="field"><label>Policy / card no.</label><input maxlength="40" id="cf_policyNumber" value="${esc(c.policyNumber||'')}"></div>
      <div class="field"><label>Claim type</label><select id="cf_claimType">${CLAIM_TYPES.map(t=>`<option ${c.claimType===t?'selected':''}>${t}</option>`).join('')}</select></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Priority</label><select id="cf_priority">${Object.keys(PRIORITY_META).map(p=>`<option ${c.priority===p?'selected':''}>${p}</option>`).join('')}</select></div>
      <div class="field"><label>Status</label><select id="cf_status">${STATUS_LIST.map(s=>`<option ${c.status===s?'selected':''}>${esc(s)}</option>`).join('')}</select></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Coordinator</label><select id="cf_coordinatorId">${staffOptionsHtml('Insurance Coordinator', c.coordinatorId)}</select></div>
      <div class="field"><label>Claim executive</label><select id="cf_executiveId">${staffOptionsHtml('Claim Executive', c.executiveId)}</select></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Estimated amount (₹)</label><input type="number" inputmode="numeric" step="1" min="0" max="99999999" data-guard="money" id="cf_estimatedAmount" value="${c.estimatedAmount||''}"></div>
      <div class="field"><label>Claimed amount (₹)</label><input type="number" inputmode="numeric" step="1" min="0" max="99999999" data-guard="money" id="cf_claimedAmount" value="${c.claimedAmount||''}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Approved amount (₹)</label><input type="number" inputmode="numeric" step="1" min="0" max="99999999" data-guard="money" id="cf_approvedAmount" value="${c.approvedAmount||''}"></div>
      <div class="field"><label>Settled amount (₹)</label><input type="number" inputmode="numeric" step="1" min="0" max="99999999" data-guard="money" id="cf_settledAmount" value="${c.settledAmount||''}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Admission date</label><input type="date" id="cf_admissionDate" value="${c.admissionDate||''}"></div>
      <div class="field"><label>Discharge date</label><input type="date" id="cf_dischargeDate" value="${c.dischargeDate||''}"></div>
    </div>
    <div class="field"><label>Next follow-up date</label><input type="date" id="cf_followUpDate" value="${c.followUpDate||''}"></div>
    <div class="field"><label>Notes</label><textarea id="cf_notes" maxlength="1000" data-counter="1">${esc(c.notes||'')}</textarea></div>
    <button class="btn primary block" type="submit">${c.id?'Save changes':(isPatientRegistration?'Register patient':'Create claim')}</button>
  </form>`;
}

function openClaimForm(existingId, mode){
  const c = existingId ? ST.claims.find(x=>x.id===existingId) : null;
  if(ST.insurers.length===0){ toast('Add at least one insurer first'); switchTab('insurers'); return; }
  const formMode = c ? 'claim' : (mode || 'claim');
  openSheet(c?'Edit claim':(formMode==='patient'?'Register patient':'New claim'), claimFormHtml(c, formMode), (sheet)=>{
    wireInputGuards(sheet);
    sheet.querySelector('#claimForm').addEventListener('submit', async (e)=>{
      e.preventDefault();
      const payload = {
        patientName: sheet.querySelector('#cf_patientName').value.trim(),
        uhid: sheet.querySelector('#cf_uhid').value.trim(),
        admissionNumber: sheet.querySelector('#cf_admissionNumber').value.trim(),
        insurerId: sheet.querySelector('#cf_insurerId').value,
        policyNumber: sheet.querySelector('#cf_policyNumber').value.trim(),
        claimType: sheet.querySelector('#cf_claimType').value,
        priority: sheet.querySelector('#cf_priority').value,
        status: sheet.querySelector('#cf_status').value,
        coordinatorId: sheet.querySelector('#cf_coordinatorId').value || null,
        executiveId: sheet.querySelector('#cf_executiveId').value || null,
        estimatedAmount: Number(sheet.querySelector('#cf_estimatedAmount').value)||0,
        claimedAmount: Number(sheet.querySelector('#cf_claimedAmount').value)||0,
        approvedAmount: Number(sheet.querySelector('#cf_approvedAmount').value)||0,
        settledAmount: Number(sheet.querySelector('#cf_settledAmount').value)||0,
        admissionDate: sheet.querySelector('#cf_admissionDate').value || null,
        dischargeDate: sheet.querySelector('#cf_dischargeDate').value || null,
        followUpDate: sheet.querySelector('#cf_followUpDate').value || null,
        notes: sheet.querySelector('#cf_notes').value,
        staffId: getLocalUserId(),
      };
      try{
        if(c) await Claims.update(c.id, payload);
        else await Claims.create(payload);
        await loadAll();
        closeSheet(); toast(c?'Claim updated':(formMode==='patient'?'Patient registered':'Claim created')); renderClaims(); renderDashboard();
        if(c) openClaimDetail(c.id);
      }catch(err){ toast(err.message); }
    });
  });
}

function openClaimDetail(id){
  const c = ST.claims.find(x=>x.id===id);
  if(!c) return;
  const sm = STATUS_META[c.status]||{c:'#6B6690'};
  const pm = PRIORITY_META[c.priority]||{c:'#6B6690'};
  const events = ST.events.filter(e=>e.claimId===id).sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt));
  const body = `
    <div class="row between">${badge(c.status, sm.c)}${badge(c.priority||'Normal', pm.c)}</div>
    <p class="small mut" style="margin:8px 0 0;">${esc(c.claimNumber)} · ${esc(insurerName(c.insurerId))}</p>
    <div class="detail-grid">
      <div class="d"><div class="l">UHID</div><div class="v">${esc(c.uhid||'—')}</div></div>
      <div class="d"><div class="l">Admission no.</div><div class="v">${esc(c.admissionNumber||'—')}</div></div>
      <div class="d"><div class="l">Policy no.</div><div class="v">${esc(c.policyNumber||'—')}</div></div>
      <div class="d"><div class="l">Claim type</div><div class="v">${esc(c.claimType||'—')}</div></div>
      <div class="d"><div class="l">Estimated</div><div class="v">${money(c.estimatedAmount)}</div></div>
      <div class="d"><div class="l">Claimed</div><div class="v">${money(c.claimedAmount)}</div></div>
      <div class="d"><div class="l">Approved</div><div class="v">${money(c.approvedAmount)}</div></div>
      <div class="d"><div class="l">Settled</div><div class="v">${money(c.settledAmount)}</div></div>
      <div class="d"><div class="l">Coordinator</div><div class="v" style="font-family:inherit;font-size:13px;">${esc(staffName(c.coordinatorId))}</div></div>
      <div class="d"><div class="l">Executive</div><div class="v" style="font-family:inherit;font-size:13px;">${esc(staffName(c.executiveId))}</div></div>
      <div class="d"><div class="l">Admitted</div><div class="v" style="font-family:inherit;font-size:13px;">${fmtDate(c.admissionDate)}</div></div>
      <div class="d"><div class="l">Discharged</div><div class="v" style="font-family:inherit;font-size:13px;">${fmtDate(c.dischargeDate)}</div></div>
    </div>
    ${c.followUpDate ? `<p class="small" style="${isOverdue(c)?'color:var(--rose);font-weight:700;':''}">Next follow-up: ${fmtDate(c.followUpDate)} ${isOverdue(c)?'(overdue)':''}</p>` : ''}
    ${c.notes ? `<div class="card small" style="margin-top:8px;">${esc(c.notes)}</div>` : ''}
    <div class="row wrap" style="gap:8px;margin:13px 0;">
      <button class="btn sm" id="btnEditClaim">Edit</button>
      <button class="btn sm primary" id="btnLogActivity">Log activity</button>
      <button class="btn sm" id="btnChangeStatus">Change status</button>
      <button class="btn sm danger" id="btnDeleteClaim">Delete</button>
    </div>
    <div class="section-label" style="margin-top:16px;">Timeline</div>
    <div class="timeline">${events.length ? events.map(e=>{
      const label = e.kind==='status' ? `${e.statusFrom?esc(e.statusFrom)+' → ':''}${esc(e.statusTo)}` : esc(e.activityType||'Activity');
      return `<div class="tl-item"><div class="tl-dot"></div><div class="tl-body"><div class="top">${esc(staffName(e.staffId))} · ${label}</div><div class="meta">${fmtDateTime(e.createdAt)}${e.minutes?' · '+e.minutes+' min':''}</div>${e.note?`<div class="note">${esc(e.note)}</div>`:''}</div></div>`;
    }).join('') : '<p class="small mut">No entries yet.</p>'}</div>
  `;
  openSheet(c.patientName, body, (sheet)=>{
    sheet.querySelector('#btnEditClaim').addEventListener('click', ()=> openClaimForm(c.id));
    sheet.querySelector('#btnLogActivity').addEventListener('click', ()=> openActivityForm(c.id));
    sheet.querySelector('#btnChangeStatus').addEventListener('click', ()=> openStatusForm(c.id));
    sheet.querySelector('#btnDeleteClaim').addEventListener('click', async ()=>{
      if(!confirm('Delete this claim and all its history? This cannot be undone.')) return;
      try{
        await Claims.remove(c.id);
        await loadAll();
        closeSheet(); toast('Claim deleted'); renderClaims(); renderDashboard();
      }catch(err){ toast(err.message); }
    });
  });
}

function openActivityForm(claimId){
  const body = `<form id="actForm">
    <div class="field"><label>Logged by</label><select id="af_staffId">${staffOptionsHtml(null, getLocalUserId())}</select></div>
    <div class="field"><label>Action type</label><select id="af_type">${ACTIVITY_TYPES.map(t=>`<option>${esc(t)}</option>`).join('')}</select></div>
    <div class="field"><label>Notes</label><textarea id="af_note" maxlength="500" data-counter="1" placeholder="What was done / outcome"></textarea></div>
    <div class="field"><label>Minutes spent (optional)</label><input type="number" inputmode="numeric" id="af_minutes" min="0" max="600" data-guard="int"></div>
    <button class="btn primary block" type="submit">Save activity</button>
  </form>`;
  openSheet('Log activity', body, (sheet)=>{
    wireInputGuards(sheet);
    sheet.querySelector('#actForm').addEventListener('submit', async (e)=>{
      e.preventDefault();
      const payload = {
        claimId, kind:'activity',
        staffId: sheet.querySelector('#af_staffId').value || null,
        activityType: sheet.querySelector('#af_type').value,
        note: sheet.querySelector('#af_note').value.trim(),
        minutes: Number(sheet.querySelector('#af_minutes').value)||0,
      };
      try{
        await Events.create(payload);
        await loadAll();
        closeSheet(); toast('Activity logged'); renderDashboard(); openClaimDetail(claimId);
      }catch(err){ toast(err.message); }
    });
  });
}

function openStatusForm(claimId){
  const c = ST.claims.find(x=>x.id===claimId);
  const body = `<form id="stForm">
    <div class="field"><label>New status</label><select id="sf_status">${STATUS_LIST.map(s=>`<option ${c.status===s?'selected':''}>${esc(s)}</option>`).join('')}</select></div>
    <div class="field"><label>Changed by</label><select id="sf_staffId">${staffOptionsHtml(null, getLocalUserId())}</select></div>
    <div class="field"><label>Note (optional)</label><textarea id="sf_note" maxlength="300" data-counter="1"></textarea></div>
    <button class="btn primary block" type="submit">Update status</button>
  </form>`;
  openSheet('Change status', body, (sheet)=>{
    wireInputGuards(sheet);
    sheet.querySelector('#stForm').addEventListener('submit', async (e)=>{
      e.preventDefault();
      const newStatus = sheet.querySelector('#sf_status').value;
      const payload = { claimId, kind:'status', statusTo:newStatus,
        staffId: sheet.querySelector('#sf_staffId').value || null,
        note: sheet.querySelector('#sf_note').value.trim() };
      try{
        if(newStatus !== c.status) await Events.create(payload);
        await loadAll();
        closeSheet(); toast('Status updated'); renderClaims(); renderDashboard(); openClaimDetail(claimId);
      }catch(err){ toast(err.message); }
    });
  });
}

/* ================= STAFF ================= */
function renderStaff(){
  const box = document.getElementById('staffList');
  if(ST.staff.length===0){
    box.innerHTML = `<div class="empty"><div class="big">🧑‍💼</div><h4>No team members yet</h4><p>Add coordinators, claim executives, and yourself.</p></div>`;
    return;
  }
  const order = {'Manager':0,'Insurance Coordinator':1,'Claim Executive':2};
  const sorted = [...ST.staff].sort((a,b)=> (order[a.role]??9)-(order[b.role]??9) || a.name.localeCompare(b.name));
  box.innerHTML = sorted.map(s=>{
    const initials = s.name.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
    return `<div class="staff-row" data-id="${s.id}">
      <div class="row" style="gap:11px;"><div class="avatar" style="--av:${avatarGradient(s.name)}">${esc(initials)}</div>
        <div><div style="font-weight:700;font-size:13.5px;">${esc(s.name)}${s.id===getLocalUserId()?' <span class="small mut">(you)</span>':''}</div>
        <div class="small mut">${esc(s.role)}${s.phone?' · '+esc(s.phone):''}</div></div>
      </div>
      <label class="toggle"><input type="checkbox" data-toggle="${s.id}" ${s.active!==false?'checked':''}><span class="track"></span></label>
    </div>`;
  }).join('');
  box.querySelectorAll('.staff-row').forEach(el=>{
    el.addEventListener('click', (e)=>{ if(e.target.closest('.toggle')) return; openStaffProfile(el.dataset.id); });
  });
  box.querySelectorAll('[data-toggle]').forEach(cb=>{
    cb.addEventListener('click', e=> e.stopPropagation());
    cb.addEventListener('change', async e=>{
      const s = ST.staff.find(x=>x.id===cb.dataset.toggle);
      try{ await Staff.update(s.id, {name:s.name, role:s.role, phone:s.phone, active:e.target.checked}); s.active = e.target.checked; renderDashboard(); }
      catch(err){ toast(err.message); e.target.checked = !e.target.checked; }
    });
  });
}
function staffFormHtml(s){
  s = s || {};
  return `<form id="staffForm">
    <div class="field"><label>Full name *</label><input required maxlength="80" id="sf_name" value="${esc(s.name||'')}"></div>
    <div class="field"><label>Role</label><select id="sf_role">${ROLES.map(r=>`<option ${s.role===r?'selected':''}>${r}</option>`).join('')}</select></div>
    <div class="field"><label>Phone (optional)</label><input type="tel" inputmode="tel" maxlength="15" data-guard="phone" id="sf_phone" value="${esc(s.phone||'')}"></div>
    <button class="btn primary block" type="submit">${s.id?'Save changes':'Add team member'}</button>
  </form>`;
}
document.getElementById('btnAddStaff').addEventListener('click', ()=>{
  openSheet('Add team member', staffFormHtml(), (sheet)=>{
    wireInputGuards(sheet);
    sheet.querySelector('#staffForm').addEventListener('submit', async e=>{
      e.preventDefault();
      const payload = {name:sheet.querySelector('#sf_name').value.trim(), role:sheet.querySelector('#sf_role').value, phone:sheet.querySelector('#sf_phone').value.trim()};
      try{
        const created = await Staff.create(payload);
        await loadAll();
        if(!getLocalUserId()) setLocalUserId(created.id);
        closeSheet(); toast('Team member added'); renderStaff(); renderDashboard(); refreshHeader();
      }catch(err){ toast(err.message); }
    });
  });
});
function openStaffProfile(id){
  const s = ST.staff.find(x=>x.id===id);
  const openClaims = ST.claims.filter(c => (c.coordinatorId===s.id||c.executiveId===s.id) && !TERMINAL.has(c.status));
  const recentActs = ST.events.filter(e=>e.staffId===s.id).sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt)).slice(0,10);
  const body = `
    <p class="small mut">${esc(s.role)}${s.phone?' · '+esc(s.phone):''}</p>
    <div class="detail-grid" style="grid-template-columns:1fr 1fr;">
      <div class="d"><div class="l">Open claims</div><div class="v">${openClaims.length}</div></div>
      <div class="d"><div class="l">Total logged actions</div><div class="v">${ST.events.filter(e=>e.staffId===s.id).length}</div></div>
    </div>
    <div class="row wrap" style="gap:8px;margin:10px 0 14px;">
      <button class="btn sm" id="btnEditStaff">Edit</button>
      <button class="btn sm" id="btnMakeMe">Set as "me"</button>
      <button class="btn sm danger" id="btnDelStaff">Delete</button>
    </div>
    <div class="section-label">Open claims</div>
    ${openClaims.length ? openClaims.map(c=>`<div class="list-row"><span>${esc(c.patientName)} · ${esc(c.claimNumber)}</span>${badge(c.status, (STATUS_META[c.status]||{}).c||'#6B6690')}</div>`).join('') : '<p class="small mut">None.</p>'}
    <div class="section-label">Recent activity</div>
    ${recentActs.length ? recentActs.map(e=>{ const c = ST.claims.find(x=>x.id===e.claimId); return `<div class="tl-item"><div class="tl-dot"></div><div class="tl-body"><div class="top">${e.kind==='status'?('Status → '+esc(e.statusTo)):esc(e.activityType)}</div><div class="meta">${c?esc(c.patientName):''} · ${fmtDateTime(e.createdAt)}</div></div></div>`; }).join('') : '<p class="small mut">No activity logged yet.</p>'}
  `;
  openSheet(s.name, body, (sheet)=>{
    sheet.querySelector('#btnEditStaff').addEventListener('click', ()=>{
      openSheet('Edit team member', staffFormHtml(s), (sh)=>{
        wireInputGuards(sh);
        sh.querySelector('#staffForm').addEventListener('submit', async e=>{
          e.preventDefault();
          try{
            await Staff.update(s.id, {name:sh.querySelector('#sf_name').value.trim(), role:sh.querySelector('#sf_role').value, phone:sh.querySelector('#sf_phone').value.trim(), active:s.active!==false});
            await loadAll();
            closeSheet(); toast('Saved'); renderStaff(); renderDashboard();
          }catch(err){ toast(err.message); }
        });
      });
    });
    sheet.querySelector('#btnMakeMe').addEventListener('click', ()=>{ setLocalUserId(s.id); closeSheet(); toast('This device is now set to '+s.name); refreshHeader(); renderDashboard(); });
    sheet.querySelector('#btnDelStaff').addEventListener('click', async ()=>{
      if(!confirm('Remove this team member? Their past history stays on claims but future assignment will show as unassigned.')) return;
      try{
        await Staff.remove(s.id);
        if(getLocalUserId()===s.id) setLocalUserId(null);
        await loadAll();
        closeSheet(); toast('Removed'); renderStaff(); renderDashboard();
      }catch(err){ toast(err.message); }
    });
  });
}

/* ================= INSURERS ================= */
function renderInsurerFilterChips(){
  const box = document.getElementById('insurerFilterChips');
  box.innerHTML = ['','Scheme','TPA','Insurer'].map(t=> `<button class="chip ${ST.insurerFilter===t?'active':''}" data-t="${t}">${t||'All'}</button>`).join('');
  box.querySelectorAll('button').forEach(b=> b.addEventListener('click', ()=>{ ST.insurerFilter = b.dataset.t; renderInsurers(true); }));
}
function renderInsurers(skipChips){
  if(!skipChips) renderInsurerFilterChips();
  const q = (document.getElementById('insurerSearch').value||'').trim().toLowerCase();
  let list = [...ST.insurers];
  if(ST.insurerFilter) list = list.filter(i=>i.type===ST.insurerFilter);
  if(q) list = list.filter(i=> i.name.toLowerCase().includes(q));
  list.sort((a,b)=>a.name.localeCompare(b.name));
  const box = document.getElementById('insurerList');
  document.querySelector('#tab-insurers .tab-sub').textContent = `${ST.insurers.length} empanelled · showing ${list.length}`;
  if(list.length===0){ box.innerHTML = `<div class="empty"><div class="big">🏥</div><h4>No matches</h4><p>Try another search or add a new insurer.</p></div>`; return; }
  box.innerHTML = list.map(i=>{
    const openCount = ST.claims.filter(c=>c.insurerId===i.id && !TERMINAL.has(c.status)).length;
    const tc = {'Scheme':'#12B886','TPA':'#2FA8E0','Insurer':'#8B5CF6'}[i.type] || '#6B6690';
    return `<div class="insurer-row" data-id="${i.id}">
      <div><div style="font-weight:700;font-size:13.5px;">${esc(i.name)}</div><div class="small mut">${badge(i.type, tc)} · ${openCount} open claim${openCount===1?'':'s'}</div></div>
      <label class="toggle"><input type="checkbox" data-toggle="${i.id}" ${i.active!==false?'checked':''}><span class="track"></span></label>
    </div>`;
  }).join('');
  box.querySelectorAll('.insurer-row').forEach(el=> el.addEventListener('click', e=>{ if(e.target.closest('.toggle')) return; openInsurerForm(el.dataset.id); }));
  box.querySelectorAll('[data-toggle]').forEach(cb=>{
    cb.addEventListener('click', e=>e.stopPropagation());
    cb.addEventListener('change', async e=>{
      const i = ST.insurers.find(x=>x.id===cb.dataset.toggle);
      try{ await Insurers.update(i.id, {name:i.name, type:i.type, active:e.target.checked}); i.active = e.target.checked; }
      catch(err){ toast(err.message); e.target.checked = !e.target.checked; }
    });
  });
}
document.getElementById('insurerSearch').addEventListener('input', ()=> renderInsurers(true));
document.getElementById('btnAddInsurer').addEventListener('click', ()=> openInsurerForm());
function openInsurerForm(id){
  const i = id ? ST.insurers.find(x=>x.id===id) : null;
  const body = `<form id="insForm">
    <div class="field"><label>Name *</label><input required maxlength="120" id="if_name" value="${esc(i?i.name:'')}"></div>
    <div class="field"><label>Type</label><select id="if_type">${INSURER_TYPES.map(t=>`<option ${i&&i.type===t?'selected':''}>${t}</option>`).join('')}</select></div>
    <button class="btn primary block" type="submit">${i?'Save changes':'Add'}</button>
    ${i?`<button type="button" class="btn danger block" id="delInsurer" style="margin-top:8px;">Delete</button>`:''}
  </form>`;
  openSheet(i?'Edit insurer':'Add insurer / scheme', body, (sheet)=>{
    wireInputGuards(sheet);
    sheet.querySelector('#insForm').addEventListener('submit', async e=>{
      e.preventDefault();
      const payload = { name: sheet.querySelector('#if_name').value.trim(), type: sheet.querySelector('#if_type').value, active: i?(i.active!==false):true };
      try{
        if(i) await Insurers.update(i.id, payload); else await Insurers.create(payload);
        await loadAll();
        closeSheet(); toast(i?'Saved':'Insurer added'); renderInsurers();
      }catch(err){ toast(err.message); }
    });
    if(i){
      sheet.querySelector('#delInsurer').addEventListener('click', async ()=>{
        if(!confirm('Delete this insurer? Existing claims will keep the reference lost.')) return;
        try{ await Insurers.remove(i.id); await loadAll(); closeSheet(); toast('Deleted'); renderInsurers(); }
        catch(err){ toast(err.message); }
      });
    }
  });
}

/* ================= REPORTS ================= */
function setReportRange(days){
  const to = new Date();
  let from;
  if(days==='month'){ from = new Date(to.getFullYear(), to.getMonth(), 1); }
  else { from = new Date(to.getTime() - Number(days)*24*3600*1000); }
  document.getElementById('repFrom').value = from.toISOString().slice(0,10);
  document.getElementById('repTo').value = to.toISOString().slice(0,10);
  renderReports();
}
document.querySelectorAll('[data-range]').forEach(b=> b.addEventListener('click', ()=> setReportRange(b.dataset.range)));
document.getElementById('repFrom').addEventListener('change', renderReports);
document.getElementById('repTo').addEventListener('change', renderReports);

function reportRange(){
  const from = document.getElementById('repFrom').value || '2000-01-01';
  const to = document.getElementById('repTo').value || '2100-01-01';
  return {from, to};
}
function renderReports(){
  if(!document.getElementById('repFrom').value) setReportRange('30');
  const {from, to} = reportRange();
  const inRange = c => (c.createdAt||'').slice(0,10) >= from && (c.createdAt||'').slice(0,10) <= to;
  const claims = ST.claims.filter(inRange);
  const totalClaimed = claims.reduce((a,c)=>a+(Number(c.claimedAmount)||0),0);
  const totalSettled = claims.filter(c=>c.status==='Settled').reduce((a,c)=>a+(Number(c.settledAmount)||0),0);
  const byStatus = {};
  claims.forEach(c=> byStatus[c.status] = (byStatus[c.status]||0)+1);
  const box = document.getElementById('reportSummary');
  box.innerHTML = `
    <div class="stat-grid">
      <div class="stat"><span class="n">${claims.length}</span><span class="l">Claims created</span></div>
      <div class="stat"><span class="n">${money(totalClaimed)}</span><span class="l">Total claimed</span></div>
      <div class="stat good"><span class="n">${money(totalSettled)}</span><span class="l">Total settled</span></div>
      <div class="stat"><span class="n">${claims.filter(isOverdue).length}</span><span class="l">Overdue in range</span></div>
    </div>
    <div class="card">${Object.entries(byStatus).sort((a,b)=>b[1]-a[1]).map(([s,n])=>`<div class="list-row"><span>${esc(s)}</span><span class="mono">${n}</span></div>`).join('') || '<p class="small mut">No claims in this range.</p>'}</div>
  `;
  // wire up export links with the current range
  document.getElementById('expClaims').href = `/api/export/claims.csv?from=${from}&to=${to}`;
  document.getElementById('expActivity').href = `/api/export/activity.csv?from=${from}&to=${to}`;
  document.getElementById('expStaff').href = `/api/export/staff.csv?from=${from}&to=${to}`;
}

/* ================= SETTINGS ================= */
function renderSettings(){
  document.getElementById('setHospitalName').value = ST.settings.hospitalName || '';
  const sel = document.getElementById('setCurrentUser');
  sel.innerHTML = '<option value="">— not set —</option>' + ST.staff.map(s=>`<option value="${s.id}" ${getLocalUserId()===s.id?'selected':''}>${esc(s.name)} (${esc(s.role)})</option>`).join('');
  document.getElementById('btnExportJson').href = '/api/export/backup.json';
}
document.getElementById('btnSettings').addEventListener('click', ()=> switchTabNoNav('settings'));
document.getElementById('saveSettingsBtn').addEventListener('click', async ()=>{
  try{
    await Settings.set('hospitalName', document.getElementById('setHospitalName').value.trim());
    setLocalUserId(document.getElementById('setCurrentUser').value || null);
    await loadAll();
    refreshHeader(); toast('Settings saved'); renderDashboard();
  }catch(err){ toast(err.message); }
});

/* ================= boot ================= */
async function init(){
  renderNav();
  try{
    await loadAll();
  }catch(err){
    document.getElementById('app').innerHTML = `<div style="padding:50px 24px;text-align:center;"><div style="font-size:40px;margin-bottom:10px;">🔌</div><h3>Can't reach the server</h3><p class="mut">${esc(err.message)}</p><p class="mut small">Check that the Docker containers are running (<span class="mono">docker compose ps</span>) and reload this page.</p></div>`;
    return;
  }
  refreshHeader();
  setReportRange('30');
  renderDashboard();
  wireInputGuards(document);
  // light polling so a second device's changes show up here too
  setInterval(async ()=>{
    try{ await loadAll(); renderActiveTab(); if(document.getElementById('tab-settings').classList.contains('active')) renderSettings(); }
    catch(e){ /* setConn already flips the dot */ }
  }, 20000);
}
init();
