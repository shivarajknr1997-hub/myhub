-- Claims360 — Hospital Insurance Desk Tracker
-- Schema + seed data, auto-run once on first container start.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('Manager','Insurance Coordinator','Claim Executive')),
  phone TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS insurers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('Scheme','TPA','Insurer')),
  active BOOLEAN NOT NULL DEFAULT true
);

CREATE SEQUENCE IF NOT EXISTS claim_seq START 1;

CREATE TABLE IF NOT EXISTS claims (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_number TEXT UNIQUE NOT NULL,
  patient_name TEXT NOT NULL,
  uhid TEXT,
  admission_number TEXT,
  insurer_id UUID REFERENCES insurers(id),
  policy_number TEXT,
  claim_type TEXT NOT NULL DEFAULT 'Cashless',
  status TEXT NOT NULL DEFAULT 'Eligibility Check',
  priority TEXT NOT NULL DEFAULT 'Normal',
  coordinator_id UUID REFERENCES staff(id),
  executive_id UUID REFERENCES staff(id),
  estimated_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  claimed_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  approved_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  settled_amount NUMERIC(14,2) NOT NULL DEFAULT 0,
  admission_date DATE,
  discharge_date DATE,
  follow_up_date DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  claim_id UUID NOT NULL REFERENCES claims(id) ON DELETE CASCADE,
  staff_id UUID REFERENCES staff(id),
  kind TEXT NOT NULL CHECK (kind IN ('status','activity')),
  status_from TEXT,
  status_to TEXT,
  activity_type TEXT,
  note TEXT,
  minutes INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_claims_status ON claims(status);
CREATE INDEX IF NOT EXISTS idx_claims_insurer ON claims(insurer_id);
CREATE INDEX IF NOT EXISTS idx_claims_coordinator ON claims(coordinator_id);
CREATE INDEX IF NOT EXISTS idx_claims_executive ON claims(executive_id);
CREATE INDEX IF NOT EXISTS idx_events_claim ON events(claim_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_events_staff ON events(staff_id, created_at DESC);

INSERT INTO settings (key, value) VALUES ('hospitalName', '"Your Hospital"')
  ON CONFLICT (key) DO NOTHING;

-- Seed 46 commonly-empanelled Karnataka / national insurers, TPAs and schemes.
INSERT INTO insurers (name, type) VALUES
  ('Ayushman Bharat – PM-JAY (ABY)','Scheme'),
  ('Yeshasvini','Scheme'),
  ('ABARK – Arogya Bhagya (Karnataka Govt Employees)','Scheme'),
  ('KASS – Karnataka Arogya Sanjeevini Scheme','Scheme'),
  ('SKDRDP','Scheme'),
  ('CGHS','Scheme'),
  ('ECHS','Scheme'),
  ('Medi Assist Insurance TPA','TPA'),
  ('MDIndia Health Insurance TPA','TPA'),
  ('Vidal Health TPA','TPA'),
  ('Paramount Health Services TPA','TPA'),
  ('Family Health Plan (FHPL) TPA','TPA'),
  ('Health India TPA','TPA'),
  ('Raksha Health Insurance TPA','TPA'),
  ('Genins India TPA','TPA'),
  ('Heritage Health TPA','TPA'),
  ('Medsave Health Insurance TPA','TPA'),
  ('Safeway TPA','TPA'),
  ('Good Health TPA','TPA'),
  ('E-Meditek TPA','TPA'),
  ('Park Mediclaim TPA','TPA'),
  ('Vipul MedCorp TPA','TPA'),
  ('United Healthcare TPA','TPA'),
  ('Star Health & Allied Insurance','Insurer'),
  ('Niva Bupa Health Insurance','Insurer'),
  ('Care Health Insurance','Insurer'),
  ('HDFC ERGO General Insurance','Insurer'),
  ('ICICI Lombard General Insurance','Insurer'),
  ('Bajaj Allianz General Insurance','Insurer'),
  ('New India Assurance','Insurer'),
  ('National Insurance Company','Insurer'),
  ('United India Insurance','Insurer'),
  ('Oriental Insurance Company','Insurer'),
  ('SBI General Insurance','Insurer'),
  ('Tata AIG General Insurance','Insurer'),
  ('Reliance General Insurance','Insurer'),
  ('Cholamandalam MS General Insurance','Insurer'),
  ('Manipal Cigna Health Insurance','Insurer'),
  ('Future Generali India Insurance','Insurer'),
  ('Universal Sompo General Insurance','Insurer'),
  ('IFFCO Tokio General Insurance','Insurer'),
  ('Royal Sundaram General Insurance','Insurer'),
  ('Aditya Birla Health Insurance','Insurer'),
  ('Liberty General Insurance','Insurer'),
  ('Kotak Mahindra General Insurance','Insurer'),
  ('Go Digit General Insurance','Insurer')
ON CONFLICT DO NOTHING;
