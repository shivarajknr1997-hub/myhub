# Claims360 — Hospital Insurance Desk Tracker (self-hosted, Docker)

A shared claims-tracking board for your hospital's insurance coordinators and claim
executives — running entirely on your own mini PC. No cloud, no per-seat charges,
no internet dependency once it's running. Everyone on your local network opens the
same address in their browser and works off the same live data.

## What's inside

| Piece | What it does |
|---|---|
| **Postgres** (`db` container) | The real, persistent database. Survives restarts and rebuilds. |
| **Node/Express API + frontend** (`app` container) | Serves the API under `/api/*` and the web app itself. |

Claims, staff, insurers, and every activity/status entry live in Postgres — so if
three coordinators open the app on three different phones, they all see the same
board, in real time-ish (the app refreshes itself every 20 seconds, and instantly
whenever you save something).

## Prerequisites

On your mini PC, install:
- **Docker Desktop** (Windows/Mac) or **Docker Engine + Docker Compose plugin** (Linux)
- That's it — no separate Node.js or Postgres install needed, Docker handles both.

## First-time setup

1. Unzip this project anywhere on the mini PC, e.g. `C:\claims360` or `~/claims360`.
2. Open a terminal in that folder.
3. Copy the environment template and set a real database password:
   ```bash
   cp .env.example .env
   ```
   Then edit `.env` and change `POSTGRES_PASSWORD` to something private.
4. Build and start everything:
   ```bash
   docker compose up -d --build
   ```
   First run downloads the Postgres and Node base images, so it needs internet
   access once. After that, everything runs fully offline/local.
5. Check it came up clean:
   ```bash
   docker compose ps
   docker compose logs -f app
   ```
   You should see `Claims360 server listening on port 8080`. Press Ctrl+C to stop
   watching logs (the app keeps running).

## Opening the app

- **On the mini PC itself:** http://localhost:8080
- **From any other phone/laptop on the same Wi-Fi/LAN:** find the mini PC's local
  IP address, then open `http://<that-ip>:8080`.

  To find the IP on the mini PC:
  - Windows: `ipconfig` → look for "IPv4 Address" (something like `192.168.1.45`)
  - Mac/Linux: `ifconfig` or `hostname -I`

  If other devices can't connect, your mini PC's firewall may be blocking inbound
  port 8080 — allow it for your local network.

Bookmark that address on every coordinator's and executive's phone — that's the
one shared board.

## Using the app

1. Go to **Settings** → set your hospital name, and add every team member under
   **Team** (Manager, Insurance Coordinators, Claim Executives).
2. On **each device**, open Settings and set "I am using this device as" to that
   person — this only affects that browser, so everyone's own actions get
   correctly attributed to them.
3. **Insurers** comes preloaded with 46 commonly-empanelled Karnataka/national
   insurers, TPAs and schemes (Ayushman Bharat, Yeshasvini, ABARK, KASS, SKDRDP,
   CGHS, ECHS, plus major TPAs and insurance companies) — edit, deactivate, or add
   more to match your exact panel of 40+.
4. **Claims** is where the daily work happens — create a claim, assign a
   coordinator and executive, then use **Log activity** and **Change status** as
   the case moves through pre-auth, discharge, billing and settlement. Every entry
   is timestamped and attributed — that's your audit trail.
5. **Dashboard** and **Reports** roll all of that up: active/overdue counts,
   per-staff performance, per-insurer breakdown, and CSV exports.

## Backups

Your data lives in a Docker-managed volume (`hc360_data`), so it survives
`docker compose down` / restarts / rebuilds. Still, back up regularly:

- **Quick backup:** in the app, Settings → "Full backup (JSON)" downloads
  everything.
- **Proper database backup** (recommended weekly):
  ```bash
  docker compose exec db pg_dump -U hc360 hc360 > backup_$(date +%F).sql
  ```
- **Restore that backup** into a fresh database:
  ```bash
  cat backup_2026-01-01.sql | docker compose exec -T db psql -U hc360 hc360
  ```

## Everyday operations

```bash
docker compose up -d          # start (after first build)
docker compose down           # stop everything (data is kept)
docker compose down -v        # ⚠️ stop AND delete the database volume — irreversible
docker compose logs -f app    # watch server logs
docker compose up -d --build  # rebuild after you or I change the code
```

## Changing the port

If 8080 is already used on your mini PC, edit `APP_PORT` in `.env`, then
`docker compose up -d --build`.

## A security note, honestly

This app has **no login screen** — anyone who can reach the address can view and
edit everything. That's fine and normal for a tool used only inside your hospital's
own Wi-Fi/LAN, on trusted staff devices.

Please **don't** forward port 8080 through your router to the public internet as-is
— an unauthenticated claims board shouldn't be reachable from outside your building.
If you later want staff to reach it while off-site, the right way is a VPN into your
network, or a reverse proxy with a login and HTTPS in front of it — happy to help
set that up when you're ready for it.

## Project layout

```
hc360-docker/
├── docker-compose.yml       # the two-container stack
├── .env.example             # copy to .env and edit
├── db/init.sql              # schema + seed data (46 insurers), runs once on first boot
└── server/
    ├── Dockerfile
    ├── package.json
    ├── src/
    │   ├── index.js         # Express entry point
    │   ├── db.js             # Postgres connection pool
    │   ├── util.js            # row mapping, CSV helper, claim-number generator
    │   └── routes/            # staff, insurers, claims, events, export, settings
    └── public/                # the web app: index.html, styles.css, app.js
```
