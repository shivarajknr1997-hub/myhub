const express = require('express');
const cors = require('cors');
const path = require('path');
const { pool } = require('./db');

const staffRoutes = require('./routes/staff');
const insurerRoutes = require('./routes/insurers');
const claimsRoutes = require('./routes/claims');
const eventsRoutes = require('./routes/events');
const exportRoutes = require('./routes/export');
const settingsRoutes = require('./routes/settings');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

app.get('/api/health', async (req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ ok: false, error: String(e.message || e) }); }
});

app.use('/api/staff', staffRoutes);
app.use('/api/insurers', insurerRoutes);
app.use('/api/claims', claimsRoutes);
app.use('/api/events', eventsRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/settings', settingsRoutes);

// error handler for the routes above
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Server error' });
});

// static frontend
const publicDir = path.join(__dirname, '..', 'public');
app.use(express.static(publicDir));
app.get('*', (req, res) => res.sendFile(path.join(publicDir, 'index.html')));

const PORT = process.env.PORT || 8080;

function start(retriesLeft) {
  pool.query('SELECT 1').then(() => {
    app.listen(PORT, '0.0.0.0', () => console.log(`Claims360 server listening on port ${PORT}`));
  }).catch(err => {
    if (retriesLeft <= 0) { console.error('Database never became ready:', err.message); process.exit(1); }
    console.log('Waiting for database to be ready...');
    setTimeout(() => start(retriesLeft - 1), 2000);
  });
}
start(30);
