const router = require('express').Router();
const { pool } = require('../db');
const { mapInsurer, clampStr } = require('../util');

router.get('/', async (req, res, next) => {
  try {
    const r = await pool.query('SELECT * FROM insurers ORDER BY name ASC');
    res.json(r.rows.map(mapInsurer));
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try {
    const { name, type } = req.body;
    if (!name || !type) return res.status(400).json({ error: 'name and type are required' });
    const r = await pool.query('INSERT INTO insurers (name, type) VALUES ($1,$2) RETURNING *', [clampStr(name.trim(), 120), type]);
    res.status(201).json(mapInsurer(r.rows[0]));
  } catch (e) { next(e); }
});

router.put('/:id', async (req, res, next) => {
  try {
    const { name, type, active } = req.body;
    const r = await pool.query(
      'UPDATE insurers SET name=$1, type=$2, active=$3 WHERE id=$4 RETURNING *',
      [clampStr(name, 120), type, active !== false, req.params.id]
    );
    if (!r.rows[0]) return res.status(404).json({ error: 'not found' });
    res.json(mapInsurer(r.rows[0]));
  } catch (e) { next(e); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    await pool.query('DELETE FROM insurers WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;
