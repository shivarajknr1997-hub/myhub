const router = require('express').Router();
const { pool } = require('../db');
const { mapStaff, clampStr } = require('../util');

router.get('/', async (req, res, next) => {
  try {
    const r = await pool.query('SELECT * FROM staff ORDER BY created_at ASC');
    res.json(r.rows.map(mapStaff));
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  try {
    const { name, role, phone } = req.body;
    if (!name || !role) return res.status(400).json({ error: 'name and role are required' });
    const r = await pool.query(
      'INSERT INTO staff (name, role, phone) VALUES ($1,$2,$3) RETURNING *',
      [clampStr(name.trim(), 80), role, phone ? clampStr(phone.trim(), 15) : null]
    );
    res.status(201).json(mapStaff(r.rows[0]));
  } catch (e) { next(e); }
});

router.put('/:id', async (req, res, next) => {
  try {
    const { name, role, phone, active } = req.body;
    const r = await pool.query(
      'UPDATE staff SET name=$1, role=$2, phone=$3, active=$4 WHERE id=$5 RETURNING *',
      [clampStr(name, 80), role, phone ? clampStr(phone, 15) : null, active !== false, req.params.id]
    );
    if (!r.rows[0]) return res.status(404).json({ error: 'not found' });
    res.json(mapStaff(r.rows[0]));
  } catch (e) { next(e); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    await pool.query('DELETE FROM staff WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;
