const router = require('express').Router();
const { pool } = require('../db');
const { mapEvent, clampStr, clampNum } = require('../util');

// GET /api/events?claimId=&staffId=&from=&to=&limit=
router.get('/', async (req, res, next) => {
  try {
    const { claimId, staffId, from, to, limit } = req.query;
    const clauses = [];
    const params = [];
    let i = 1;
    if (claimId) { clauses.push(`claim_id = $${i++}`); params.push(claimId); }
    if (staffId) { clauses.push(`staff_id = $${i++}`); params.push(staffId); }
    if (from) { clauses.push(`created_at >= $${i++}`); params.push(from); }
    if (to) { clauses.push(`created_at <= $${i++}`); params.push(to + ' 23:59:59'); }
    const where = clauses.length ? 'WHERE ' + clauses.join(' AND ') : '';
    const lim = Math.min(Number(limit) || 200, 1000);
    const r = await pool.query(`SELECT * FROM events ${where} ORDER BY created_at DESC LIMIT ${lim}`, params);
    res.json(r.rows.map(mapEvent));
  } catch (e) { next(e); }
});

// POST /api/events  { claimId, staffId, kind:'activity'|'status', activityType, statusTo, note, minutes }
router.post('/', async (req, res, next) => {
  const client = await pool.connect();
  try {
    const b = req.body;
    if (!b.claimId || !b.kind) return res.status(400).json({ error: 'claimId and kind are required' });
    await client.query('BEGIN');

    let statusFrom = null;
    if (b.kind === 'status') {
      const cur = await client.query('SELECT status FROM claims WHERE id=$1', [b.claimId]);
      if (!cur.rows[0]) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'claim not found' }); }
      statusFrom = cur.rows[0].status;
      await client.query('UPDATE claims SET status=$1, updated_at=now() WHERE id=$2', [b.statusTo, b.claimId]);
    } else {
      await client.query('UPDATE claims SET updated_at=now() WHERE id=$1', [b.claimId]);
    }

    const ins = await client.query(
      `INSERT INTO events (claim_id, staff_id, kind, status_from, status_to, activity_type, note, minutes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
      [b.claimId, b.staffId || null, b.kind, statusFrom, b.statusTo || null,
       b.activityType || null, clampStr(b.note, 500) || '', clampNum(b.minutes, 0, 600)]
    );
    await client.query('COMMIT');
    res.status(201).json(mapEvent(ins.rows[0]));
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

module.exports = router;
