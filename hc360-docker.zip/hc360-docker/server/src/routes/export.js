const router = require('express').Router();
const { pool } = require('../db');
const { mapStaff, mapInsurer, mapClaim, mapEvent, toCSV } = require('../util');

function rangeClause(col, from, to, params, startIdx) {
  const clauses = [];
  let i = startIdx;
  if (from) { clauses.push(`${col} >= $${i++}`); params.push(from); }
  if (to) { clauses.push(`${col} <= $${i++}`); params.push(to + ' 23:59:59'); }
  return { clause: clauses.length ? 'WHERE ' + clauses.join(' AND ') : '', next: i };
}

router.get('/claims.csv', async (req, res, next) => {
  try {
    const { from, to } = req.query;
    const params = [];
    const { clause } = rangeClause('c.created_at', from, to, params, 1);
    const r = await pool.query(
      `SELECT c.*, i.name AS insurer_name, s1.name AS coordinator_name, s2.name AS executive_name
       FROM claims c
       LEFT JOIN insurers i ON i.id = c.insurer_id
       LEFT JOIN staff s1 ON s1.id = c.coordinator_id
       LEFT JOIN staff s2 ON s2.id = c.executive_id
       ${clause} ORDER BY c.created_at DESC`, params
    );
    const rows = r.rows.map(row => ({
      claimNumber: row.claim_number, patientName: row.patient_name, uhid: row.uhid,
      insurer: row.insurer_name, policyNumber: row.policy_number, claimType: row.claim_type,
      status: row.status, priority: row.priority, coordinator: row.coordinator_name || '',
      executive: row.executive_name || '', estimatedAmount: row.estimated_amount,
      claimedAmount: row.claimed_amount, approvedAmount: row.approved_amount, settledAmount: row.settled_amount,
      admissionDate: row.admission_date, dischargeDate: row.discharge_date, followUpDate: row.follow_up_date,
      createdAt: row.created_at, updatedAt: row.updated_at,
    }));
    const headers = ['claimNumber','patientName','uhid','insurer','policyNumber','claimType','status','priority',
      'coordinator','executive','estimatedAmount','claimedAmount','approvedAmount','settledAmount',
      'admissionDate','dischargeDate','followUpDate','createdAt','updatedAt'];
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="claims_export.csv"');
    res.send(toCSV(rows, headers));
  } catch (e) { next(e); }
});

router.get('/activity.csv', async (req, res, next) => {
  try {
    const { from, to } = req.query;
    const params = [];
    const { clause } = rangeClause('e.created_at', from, to, params, 1);
    const r = await pool.query(
      `SELECT e.*, c.claim_number, c.patient_name, s.name AS staff_name
       FROM events e
       LEFT JOIN claims c ON c.id = e.claim_id
       LEFT JOIN staff s ON s.id = e.staff_id
       ${clause} ORDER BY e.created_at DESC`, params
    );
    const rows = r.rows.map(row => ({
      date: new Date(row.created_at).toISOString().slice(0,10),
      time: new Date(row.created_at).toTimeString().slice(0,8),
      staff: row.staff_name || '', claimNumber: row.claim_number || '', patientName: row.patient_name || '',
      kind: row.kind, detail: row.kind === 'status' ? `${row.status_from||''} -> ${row.status_to||''}` : (row.activity_type||''),
      minutes: row.minutes, note: row.note || '',
    }));
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="activity_log_export.csv"');
    res.send(toCSV(rows, ['date','time','staff','claimNumber','patientName','kind','detail','minutes','note']));
  } catch (e) { next(e); }
});

router.get('/staff.csv', async (req, res, next) => {
  try {
    const { from, to } = req.query;
    const fromT = from ? new Date(from).getTime() : -Infinity;
    const toT = to ? new Date(to + 'T23:59:59').getTime() : Infinity;
    const inRange = (d) => { const t = new Date(d).getTime(); return t >= fromT && t <= toT; };

    const [staffR, eventsR, claimsR] = await Promise.all([
      pool.query('SELECT * FROM staff ORDER BY name'),
      pool.query('SELECT * FROM events'),
      pool.query("SELECT * FROM claims WHERE status='Settled'"),
    ]);

    const rows = staffR.rows.map(s => {
      const acts = eventsR.rows.filter(e => e.staff_id === s.id && inRange(e.created_at));
      const settled = claimsR.rows.filter(c => (c.coordinator_id === s.id || c.executive_id === s.id) && inRange(c.updated_at));
      return {
        name: s.name, role: s.role,
        actionsLogged: acts.length,
        minutesLogged: acts.reduce((a, e) => a + (e.minutes || 0), 0),
        claimsSettled: settled.length,
        amountSettled: settled.reduce((a, c) => a + Number(c.settled_amount || 0), 0),
      };
    });
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="staff_summary_export.csv"');
    res.send(toCSV(rows, ['name','role','actionsLogged','minutesLogged','claimsSettled','amountSettled']));
  } catch (e) { next(e); }
});

router.get('/backup.json', async (req, res, next) => {
  try {
    const [staff, insurers, claims, events, settings] = await Promise.all([
      pool.query('SELECT * FROM staff'), pool.query('SELECT * FROM insurers'),
      pool.query('SELECT * FROM claims'), pool.query('SELECT * FROM events'),
      pool.query('SELECT * FROM settings'),
    ]);
    const dump = {
      staff: staff.rows.map(mapStaff), insurers: insurers.rows.map(mapInsurer),
      claims: claims.rows.map(mapClaim), events: events.rows.map(mapEvent),
      settings: Object.fromEntries(settings.rows.map(r => [r.key, r.value])),
      exportedAt: new Date().toISOString(),
    };
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="claims360_backup_${new Date().toISOString().slice(0,10)}.json"`);
    res.send(JSON.stringify(dump, null, 2));
  } catch (e) { next(e); }
});

module.exports = router;
