const router = require('express').Router();
const { pool } = require('../db');
const { mapClaim, nextClaimNumber, clampStr, clampNum } = require('../util');
const MAX_AMOUNT = 99999999;

// GET /api/claims?status=&insurerId=&staffId=&overdue=1&q=
router.get('/', async (req, res, next) => {
  try {
    const { status, insurerId, staffId, overdue, q } = req.query;
    const clauses = [];
    const params = [];
    let i = 1;

    if (status) { clauses.push(`status = $${i++}`); params.push(status); }
    if (insurerId) { clauses.push(`insurer_id = $${i++}`); params.push(insurerId); }
    if (staffId) { clauses.push(`(coordinator_id = $${i} OR executive_id = $${i})`); params.push(staffId); i++; }
    if (overdue === '1') {
      clauses.push(`follow_up_date < CURRENT_DATE AND status NOT IN ('Settled','Closed','Denied / Rejected')`);
    }
    if (q) {
      clauses.push(`(patient_name ILIKE $${i} OR claim_number ILIKE $${i} OR uhid ILIKE $${i} OR policy_number ILIKE $${i})`);
      params.push(`%${q}%`); i++;
    }
    const where = clauses.length ? 'WHERE ' + clauses.join(' AND ') : '';
    const r = await pool.query(`SELECT * FROM claims ${where} ORDER BY updated_at DESC`, params);
    res.json(r.rows.map(mapClaim));
  } catch (e) { next(e); }
});

router.get('/:id', async (req, res, next) => {
  try {
    const r = await pool.query('SELECT * FROM claims WHERE id=$1', [req.params.id]);
    if (!r.rows[0]) return res.status(404).json({ error: 'not found' });
    res.json(mapClaim(r.rows[0]));
  } catch (e) { next(e); }
});

router.post('/', async (req, res, next) => {
  const client = await pool.connect();
  try {
    const b = req.body;
    if (!b.patientName || !b.insurerId) return res.status(400).json({ error: 'patientName and insurerId are required' });
    await client.query('BEGIN');
    const claimNumber = await nextClaimNumber();
    const status = b.status || 'Eligibility Check';
    const ins = await client.query(
      `INSERT INTO claims (claim_number, patient_name, uhid, admission_number, insurer_id, policy_number,
        claim_type, status, priority, coordinator_id, executive_id, estimated_amount, claimed_amount,
        approved_amount, settled_amount, admission_date, discharge_date, follow_up_date, notes)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
       RETURNING *`,
      [claimNumber, clampStr(b.patientName.trim(), 100), clampStr(b.uhid, 40) || null, clampStr(b.admissionNumber, 40) || null, b.insurerId,
       clampStr(b.policyNumber, 40) || null, b.claimType || 'Cashless', status, b.priority || 'Normal',
       b.coordinatorId || null, b.executiveId || null, clampNum(b.estimatedAmount, 0, MAX_AMOUNT), clampNum(b.claimedAmount, 0, MAX_AMOUNT),
       clampNum(b.approvedAmount, 0, MAX_AMOUNT), clampNum(b.settledAmount, 0, MAX_AMOUNT), b.admissionDate || null, b.dischargeDate || null,
       b.followUpDate || null, clampStr(b.notes, 1000) || null]
    );
    const claim = ins.rows[0];
    await client.query(
      `INSERT INTO events (claim_id, staff_id, kind, status_from, status_to, note)
       VALUES ($1,$2,'status',NULL,$3,'Claim created')`,
      [claim.id, b.staffId || null, status]
    );
    await client.query('COMMIT');
    res.status(201).json(mapClaim(claim));
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

router.put('/:id', async (req, res, next) => {
  const client = await pool.connect();
  try {
    const b = req.body;
    await client.query('BEGIN');
    const prevR = await client.query('SELECT status FROM claims WHERE id=$1', [req.params.id]);
    if (!prevR.rows[0]) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'not found' }); }
    const prevStatus = prevR.rows[0].status;

    const upd = await client.query(
      `UPDATE claims SET patient_name=$1, uhid=$2, admission_number=$3, insurer_id=$4, policy_number=$5,
        claim_type=$6, status=$7, priority=$8, coordinator_id=$9, executive_id=$10, estimated_amount=$11,
        claimed_amount=$12, approved_amount=$13, settled_amount=$14, admission_date=$15, discharge_date=$16,
        follow_up_date=$17, notes=$18, updated_at=now()
       WHERE id=$19 RETURNING *`,
      [clampStr(b.patientName, 100), clampStr(b.uhid, 40) || null, clampStr(b.admissionNumber, 40) || null, b.insurerId, clampStr(b.policyNumber, 40) || null,
       b.claimType, b.status, b.priority, b.coordinatorId || null, b.executiveId || null,
       clampNum(b.estimatedAmount, 0, MAX_AMOUNT), clampNum(b.claimedAmount, 0, MAX_AMOUNT), clampNum(b.approvedAmount, 0, MAX_AMOUNT), clampNum(b.settledAmount, 0, MAX_AMOUNT),
       b.admissionDate || null, b.dischargeDate || null, b.followUpDate || null, clampStr(b.notes, 1000) || null, req.params.id]
    );
    const claim = upd.rows[0];
    if (prevStatus !== b.status) {
      await client.query(
        `INSERT INTO events (claim_id, staff_id, kind, status_from, status_to, note)
         VALUES ($1,$2,'status',$3,$4,$5)`,
        [claim.id, b.staffId || null, prevStatus, b.status, b.statusNote || '']
      );
    }
    await client.query('COMMIT');
    res.json(mapClaim(claim));
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    await pool.query('DELETE FROM claims WHERE id=$1', [req.params.id]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;
