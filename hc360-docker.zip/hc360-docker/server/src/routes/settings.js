const router = require('express').Router();
const { pool } = require('../db');

router.get('/', async (req, res, next) => {
  try {
    const r = await pool.query('SELECT * FROM settings');
    const out = {};
    r.rows.forEach(row => { out[row.key] = row.value; });
    res.json(out);
  } catch (e) { next(e); }
});

router.put('/:key', async (req, res, next) => {
  try {
    let { value } = req.body;
    if (typeof value === 'string') value = value.slice(0, 200);
    await pool.query(
      'INSERT INTO settings (key, value) VALUES ($1,$2) ON CONFLICT (key) DO UPDATE SET value=$2',
      [req.params.key, JSON.stringify(value)]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;
