const { pool } = require('./db');

function mapStaff(r) {
  return { id: r.id, name: r.name, role: r.role, phone: r.phone, active: r.active, createdAt: r.created_at };
}
function mapInsurer(r) {
  return { id: r.id, name: r.name, type: r.type, active: r.active };
}
function mapClaim(r) {
  return {
    id: r.id, claimNumber: r.claim_number, patientName: r.patient_name, uhid: r.uhid,
    admissionNumber: r.admission_number, insurerId: r.insurer_id, policyNumber: r.policy_number,
    claimType: r.claim_type, status: r.status, priority: r.priority,
    coordinatorId: r.coordinator_id, executiveId: r.executive_id,
    estimatedAmount: Number(r.estimated_amount), claimedAmount: Number(r.claimed_amount),
    approvedAmount: Number(r.approved_amount), settledAmount: Number(r.settled_amount),
    admissionDate: r.admission_date, dischargeDate: r.discharge_date, followUpDate: r.follow_up_date,
    notes: r.notes, createdAt: r.created_at, updatedAt: r.updated_at,
  };
}
function mapEvent(r) {
  return {
    id: r.id, claimId: r.claim_id, staffId: r.staff_id, kind: r.kind,
    statusFrom: r.status_from, statusTo: r.status_to, activityType: r.activity_type,
    note: r.note, minutes: r.minutes, createdAt: r.created_at,
  };
}

async function nextClaimNumber() {
  const year = new Date().getFullYear();
  const r = await pool.query("SELECT nextval('claim_seq') AS n");
  const n = String(r.rows[0].n).padStart(4, '0');
  return `CLM-${year}-${n}`;
}

function csvEscape(v) {
  if (v === undefined || v === null) return '';
  const s = String(v);
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}
function toCSV(rows, headers) {
  const lines = [headers.join(',')];
  for (const row of rows) lines.push(headers.map(h => csvEscape(row[h])).join(','));
  return lines.join('\n');
}

function clampStr(s, max) {
  if (s === undefined || s === null) return s;
  return String(s).slice(0, max);
}
function clampNum(n, min, max) {
  n = Number(n);
  if (!Number.isFinite(n)) n = 0;
  if (n < min) n = min;
  if (n > max) n = max;
  return n;
}

module.exports = { mapStaff, mapInsurer, mapClaim, mapEvent, nextClaimNumber, toCSV, clampStr, clampNum };
